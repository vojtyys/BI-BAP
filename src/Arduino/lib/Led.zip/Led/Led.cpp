/*
Led.cpp - Implementační soubor knihovny pro ovládání LED.
*/

#include "Arduino.h"
#include "Led.h"

//==============================================================================
Led::Led(int pin) {
  m_pin = pin;                //nastavení čísla pinu
  m_intensity = 0;        //intenzita světla je na počátku 0
  pinMode(m_pin, OUTPUT);     //nastavení pinu jako výstup
  digitalWrite(m_pin, LOW);   //led je na začátku vypnutá
}

//------------------------------------------------------------------------------
void Led::on() {
	Led::setDim(255);  //zapnuti LED 
}

//------------------------------------------------------------------------------
void Led::off() {
  Led::setDim(0);     //vypnutí led
}

//------------------------------------------------------------------------------
void Led::setDim(byte intensity) {
  analogWrite(m_pin, intensity);   //nastavení stmívání
	m_intensity = intensity;  
}

//------------------------------------------------------------------------------
byte Led::getDim(){
    return m_intensity;
}
//==============================================================================